import os

os.system('python load_electricity.py')
os.system('python load_health_spending.py')
os.system('python load_income.py')
os.system('python load_le.py')
os.system('python load_pop.py')
